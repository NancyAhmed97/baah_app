import React from 'react';
import { View, Text } from 'react-native';

const SearchScreen = () => {
  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text>Message Screen</Text>
      <Text>Under construction...</Text>
    </View>
  );
}

export default SearchScreen;
